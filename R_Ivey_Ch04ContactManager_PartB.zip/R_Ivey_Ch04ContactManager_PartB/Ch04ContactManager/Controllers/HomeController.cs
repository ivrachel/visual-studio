﻿using Ch04ContactManager.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Ch04ContactManager.Controllers
{
    public class HomeController : Controller
    {
      
        private ContactContext Context { get; set; }

        public HomeController(ContactContext ctx)
        {
            Context = ctx;
        }


        public IActionResult Index()
        {
            //Include Linq query here to select Contacts.  Don't forget to include the Category.

            var contacts = Context.Contacts
                .Include(c => c.Category)
                .OrderBy( c=> c.Firstname)
                .ToList();

            return View(contacts);
        }

    }
}