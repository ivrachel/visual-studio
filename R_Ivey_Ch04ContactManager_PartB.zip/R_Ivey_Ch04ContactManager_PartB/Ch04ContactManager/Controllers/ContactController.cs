﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Ch04ContactManager.Models;
using System.Diagnostics.Eventing.Reader;

namespace Ch04ContactManager.Controllers
{
    public class ContactController : Controller
    {
        private ContactContext context { get; set; }

        public ContactController(ContactContext ctx)
        {
            context = ctx;
        }

        //Get  - add new movie
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            ViewBag.Categories = context.Categories.OrderBy(g => g.Name).ToList();
            var model = new Contact();
            return View("AddEdit", model);
        }

        //get - edit movie
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            ViewBag.Categories = context.Categories.OrderBy(g => g.Name).ToList();
            //var model = context.Movies.FirstOrDefault(m => m.MovieId == id);
            var model = context.Contacts.Find(id);
            return View("AddEdit", model);
        }

        //post - save a movie for either add or edit in the database table
        [HttpPost]
        public IActionResult Save(Contact contact)
        {
            if (ModelState.IsValid)
            {
                //is this add or edit update
                if (contact.ContactId == 0)
                {
                    contact.DateAdded = DateTime.Now;
                    context.Contacts.Add(contact);
                }
                else
                {
                    context.Contacts.Update(contact);
                }
                context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Action = (contact.ContactId == 0) ? "Add" : "Edit";
                ViewBag.Categories = context.Categories.OrderBy(g => g.Name).ToList();
                return View("AddEdit", movie);
            }
        }

        //Get delete movie
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var model = context.Contacts.Find(id);
            return View("Delete", model);
        }

        //post delete movie
        [HttpPost]
        public IActionResult Delete(Contact contact)
        {
            context.Contacts.Remove(contact);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }


        public IActionResult Index()
        {
            return View();
        }
    }
}
