﻿namespace Ch04ContactManager.Models
{
    //Starter application files for Homework 4-1 Part B
    public class Category
    {
        public int CategoryId { get; set; }

        public string Name { get; set; }

    }
}
