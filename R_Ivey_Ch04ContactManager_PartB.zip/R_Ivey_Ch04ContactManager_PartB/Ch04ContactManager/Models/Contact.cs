﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

//Starter application files for Homework 4-1 Part B

namespace Ch04ContactManager.Models
{
    public class Contact
    {
        public int ContactId { get; set; }

        [Required(ErrorMessage = "Please enter first name.")    ]
        public string Firstname { get; set; }

        [Required(ErrorMessage = "Please enter last name.")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "Please enter phone.")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter email.")]
        public string Email { get; set; }  
        public string? Organization { get; set; } //Validation is not needed for Organization because it is not required

        public DateTime? DateAdded { get; set; }  //Validation is not needed for DateAdded because the date will be set in code

        //Code the CategoryId foreign key for Category here
        [Required(ErrorMessage ="Please select a category.")]
        public int? CategoryId { get; set; }

        //Code the Category property here to relate Contact to Category

        [ValidateNever]
        public Category Category { get; set; }

    }
}
