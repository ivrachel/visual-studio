﻿using Ch03FutureValue.Models;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Emit;

namespace Ch02FutureValue.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet] 
        public IActionResult Index()
        {

            var model = new FutureValueModel();
            ViewBag.FV = 0;
            return View(model);
        }


        [HttpPost]
        public IActionResult Index(FutureValueModel model)
        {
            var modelFV = new FutureValueModel();
            if (ModelState.IsValid)
            {
                modelFV.MonthlyInvestment = model.MonthlyInvestment;
                modelFV.YearlyInterestRate = model.YearlyInterestRate;
                modelFV.Years = model.Years;
                ViewBag.FV = model.CalculateFutureValue();
            }
            else
            {
                ViewBag.FV = 0;
            }

            return View(modelFV);

        }
    }
}
