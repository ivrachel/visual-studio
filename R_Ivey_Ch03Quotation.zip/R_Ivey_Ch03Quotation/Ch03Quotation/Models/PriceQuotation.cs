﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Ch03Quotation.Models
{
    public class PriceQuotation
    {
        [Required(ErrorMessage = "Please enter the subtotal")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Subtotal must be greater than 0")]

        public decimal? Subtotal { get; set; }

        [Required(ErrorMessage = "Please enter the discount percent")]
        [Range(1, 100, ErrorMessage = "Discount percent must be between 1 and 100")]

        public decimal? DiscountPercent { get; set; }


        public decimal? CalculateDiscountAmount()
        {
            return 10;

        }

        public decimal? CalculateTotal()
        {

            return 90;

        }

    }
}
