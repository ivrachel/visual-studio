﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.ComponentModel.DataAnnotations;

namespace Ch02FutureValue.Models
{
    public class FutureValueModel
    {
        [Required(ErrorMessage = "Please enter a monthly investment.")]
        [Range(1, 500, ErrorMessage = "Monthly Investment amount must be between 1 and 500.")]
        public decimal? MonthlyInvestment { get; set; }
        [Required(ErrorMessage = "Please enter a yearly interest rate.")]
        [Range(.1, 10.0, ErrorMessage = "Yearly interest rate must be between .1 and 10.0")]
        public decimal? YearlyInterestRate { get; set; }
        [Required(ErrorMessage = "Please enter a number of years.")]
        [Range(1, 50, ErrorMessage = "Number of year must be between 1 and 50.")]
        public int? Years { get; set; }


        [Required(ErrorMessage = "Please enter a tax rate.")]
        [Range(.1, 40.0, ErrorMessage = "Tax rate must be between .1 and 40.0")]
        public decimal? TaxRate { get; set; }

        //Calculate Future Value
        public decimal? CalculateFutureValue()
        {
            int? months = Years * 12;
            decimal? monthlyInterestRate = YearlyInterestRate / 12 / 100;
            decimal? futureValue = 0;
            for (int i = 0; i < months; i++)
            {
                futureValue = (futureValue + MonthlyInvestment) * (1 + monthlyInterestRate);
            }
            return futureValue;
        }

        //calculate tax amount
        public decimal? CalculateTaxAmount()
        {
            //future value * tax rate as a decimal
            return CalculateFutureValue() * (TaxRate / 100);
        }

        //calculate future value amount after taxes are dedcuted

    public decimal? CalculateAfterTaxDeduction()
        {
            //future value - tax amt
            return CalculateFutureValue() - CalculateTaxAmount();
        }
    }
}