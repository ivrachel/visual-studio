﻿using Microsoft.AspNetCore.Mvc;
using Ch02FutureValue.Models;

namespace Ch02FutureValue.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            
            ViewBag.FV = 0;
            ViewBag.TaxAmt = 0;
            ViewBag.FVAfterTaxes = 0;

            return View();
        }

        [HttpPost]
        public IActionResult Index(FutureValueModel model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.FV = model.CalculateFutureValue();
                ViewBag.TaxAmt = model.CalculateTaxAmount();
                ViewBag.FVAfterTaxes = model.CalculateAfterTaxDeduction();

            }
            else
            {
                ViewBag.FV = 0;
                ViewBag.TaxAmt = 0;
                ViewBag.FVAfterTaxes = 0;
            }
            ViewBag.FV = model.CalculateFutureValue();
            return View(model);
        }
    }
}
