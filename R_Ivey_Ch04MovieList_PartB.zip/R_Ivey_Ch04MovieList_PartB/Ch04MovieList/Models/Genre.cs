﻿//Starter application files for Practice 4-1 Part B

namespace Ch04MovieList.Models
{
    public class Genre
    {

        public string GenreId { get; set; }

        public string Name { get; set; }
    }
}
