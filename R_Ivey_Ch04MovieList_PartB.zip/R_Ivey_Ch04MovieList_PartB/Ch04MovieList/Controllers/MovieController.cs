﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Ch04MovieList.Models;
using System.Diagnostics.Eventing.Reader;

namespace Ch04MovieList.Controllers
{
    public class MovieController : Controller
    {
        private MovieContext context { get; set; }

        public MovieController(MovieContext ctx)
        {
            context = ctx;
        }

        //Get  - add new movie
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";
            ViewBag.Genres = context.Genres.OrderBy(g => g.Name).ToList();
            var model = new Movie();
            return View("AddEdit", model);
        }

        //get - edit movie
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            ViewBag.Genres = context.Genres.OrderBy(g => g.Name).ToList();
            //var model = context.Movies.FirstOrDefault(m => m.MovieId == id);
            var model = context.Movies.Find(id);
            return View("AddEdit", model);
        }

        //post - save a movie for either add or edit in the database table
        [HttpPost]
        public IActionResult Save(Movie movie)
        {
            if(ModelState.IsValid)
            {
                //is this add or edit update
                if (movie.MovieId == 0)
                {
                    context.Movies.Add(movie);
                }
                else
                {
                    context.Movies.Update(movie);
                }
                context.SaveChanges();
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.Action = (movie.MovieId == 0) ? "Add" : "Edit";
                ViewBag.Genres = context.Genres.OrderBy(g => g.Name).ToList();
                return View("AddEdit", movie);
            }
        }

        //Get delete movie
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var model = context.Movies.Find(id);
            return View("Delete", model);
        }

        //post delete movie
        [HttpPost]
        public IActionResult Delete(Movie movie)
        {
            context.Movies.Remove(movie);
            context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
