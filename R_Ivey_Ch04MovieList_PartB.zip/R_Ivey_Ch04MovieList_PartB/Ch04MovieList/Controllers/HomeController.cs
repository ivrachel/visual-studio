﻿using Ch04MovieList.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;

//Starter application files for Practice 4-1 Part B

namespace Ch04MovieList.Controllers
{
    public class HomeController : Controller
    {
        private MovieContext Context { get; set; }

        public HomeController(MovieContext ctx)
        {
            Context = ctx;
        }

        public IActionResult Index()
        {

            var movies = Context.Movies
                .Include(m => m.Genre)
                .OrderBy(m => m.Name)
                .ToList();

            return View(movies);
        }

    }
}