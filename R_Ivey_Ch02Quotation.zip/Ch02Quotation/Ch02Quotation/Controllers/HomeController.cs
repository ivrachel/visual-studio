﻿using Microsoft.AspNetCore.Mvc;
using Ch02Quotation.Models;


namespace Ch02Quotation.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {

            ViewBag.DiscountAmount = 0;
            ViewBag.Total = 0;

            return View();
        }

        [HttpPost]
        public IActionResult Index(Quotation model)
        {
            if (ModelState.IsValid)
            {
                ViewBag.DiscountAmount = model.CalculateDiscountAmount();
                ViewBag.Total = model.CalculateTotal();

            }
            else
            {
                ViewBag.DiscountAmount = 0;
                ViewBag.Total = 0;
            }
            
            return View(model);
        }
    }
}
