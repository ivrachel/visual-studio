using Microsoft.AspNetCore.Mvc.ViewFeatures;
using System.ComponentModel.DataAnnotations;

namespace Ch02Quotation.Models
{
    public class Quotation
    {
        [Required(ErrorMessage = "Please enter a subtotal. Subtotal required.")]
        [Range(1, 9999999.0, ErrorMessage = "Subtotal amount must be between 1 and 9999999.0")]
        public decimal? Subtotal { get; set; }
        [Required(ErrorMessage = "Please enter a discount percent. Discount percent required.")]
        [Range(0, 100, ErrorMessage = "Yearly interest rate must be between 0 and 100")]
        public decimal? DiscountPercent { get; set; }
        


        

        //Calculate Discount Amount and Total
    

        //calculate tax amount
        public decimal? CalculateDiscountAmount()
        {
            //future value * tax rate as a decimal
            return Subtotal * (DiscountPercent/100);
        }

        //calculate future value amount after taxes are dedcuted

        public decimal? CalculateTotal()
        {
            //future value - tax amt
            return Subtotal - CalculateDiscountAmount();
        }
    }
}