﻿namespace R_Ivey_FirstMVCApp.Models
{
    public class DogViewModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
