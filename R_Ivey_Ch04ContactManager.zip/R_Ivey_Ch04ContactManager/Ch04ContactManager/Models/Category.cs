﻿namespace Ch04ContactManager.Models
{
    public class Category
    {
        public int CategoryId { get; set; }

        public string Name { get; set; }    
    }
}
