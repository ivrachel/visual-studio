﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace Ch04ContactManager.Models
{
    public class Contact
    {
        [Required(ErrorMessage = "Please enter a ContactID.")]
        public int? ContactId { get; set; }

        [Required(ErrorMessage = "Please enter a First Name.")]
        public string Firstname { get; set; }

        [Required(ErrorMessage = "Please enter a Last Name.")]
        public string Lastname { get; set; }

        [Required(ErrorMessage = "Please enter a phone number.")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter an email address.")]
        public string Email { get; set; }  

        

        public string? Organization { get; set; } //Validation is not needed for Organization because it is not required

        public DateTime? DateAdded { get; set; }  //Validation is not needed for DateAdded because the date will be set in code

        //Code the CategoryId foreign key for Category here

        public int CategoryId { get; set; }

        //Code the Category property here to relate Contact to Category

        [ValidateNever]
        public Category Category { get; set; }


    }
}
