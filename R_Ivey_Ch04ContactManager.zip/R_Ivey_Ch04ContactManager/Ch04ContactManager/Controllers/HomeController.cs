﻿using Ch04ContactManager.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using System;

namespace Ch04ContactManager.Controllers
{
    public class HomeController : Controller
    {
        private ContactContext context { get; set; }

        public HomeController(ContactContext ctx)
        {
            context = ctx;

        }


        public IActionResult Index()
        {
            //Include Linq query here to select Contacts.  Don't forget to include the Category.
            var contacts = context.Contacts
                .Include(m => m.Category)
                .Where(m => m.CategoryId == 2)
                .OrderBy(t => t.Lastname)
                .ToList();
            return View(contacts);
        }

    }
}