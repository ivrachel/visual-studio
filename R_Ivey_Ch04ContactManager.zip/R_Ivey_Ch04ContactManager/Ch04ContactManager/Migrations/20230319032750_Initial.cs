﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ch04ContactManager.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    ContactId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Firstname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Lastname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CategoryId = table.Column<int>(type: "int", nullable: false),
                    Organization = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DateAdded = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.ContactId);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "Name" },
                values: new object[,]
                {
                    { 1, "Family" },
                    { 2, "Friend" },
                    { 3, "Work" },
                    { 4, "Other" }
                });

            migrationBuilder.InsertData(
                table: "Contacts",
                columns: new[] { "ContactId", "CategoryId", "DateAdded", "Email", "Firstname", "Lastname", "Organization", "Phone" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2023, 3, 18, 22, 27, 49, 902, DateTimeKind.Local).AddTicks(4623), "MaryEllen@yahoo.com", "Mary Ellen", "Walton", null, "555-123-4567" },
                    { 2, 2, new DateTime(2023, 3, 18, 22, 27, 49, 902, DateTimeKind.Local).AddTicks(4673), "delores@hotmail.com", "Delores", "Del Rio", null, "555-987-6543" },
                    { 3, 3, new DateTime(2023, 3, 18, 22, 27, 49, 902, DateTimeKind.Local).AddTicks(4676), "efren@aol.com", "Efren", "Herrera", null, "555-456-7890" },
                    { 4, 2, new DateTime(2023, 3, 18, 22, 27, 49, 902, DateTimeKind.Local).AddTicks(4680), "swilliams@gmail.com", "Sam", "Williams", null, "555-454-9870" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "Contacts");
        }
    }
}
